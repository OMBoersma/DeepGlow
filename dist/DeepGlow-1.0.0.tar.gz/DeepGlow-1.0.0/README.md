# DeepGlow
A neural network emulator for BOXFIT
